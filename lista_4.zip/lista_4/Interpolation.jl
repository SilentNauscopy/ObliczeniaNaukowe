module Interpolation
#=
    @author=Bartosz Banasik
=#
export warNewton, naturalna, ilorazyRoznicowe, rysujNnfx
include("rysuj.jl")
end
